# ABOUT

This folder contains notebook files for various Simple Linear Regression and Multiple Linear Regression Tutorials and Exercises
